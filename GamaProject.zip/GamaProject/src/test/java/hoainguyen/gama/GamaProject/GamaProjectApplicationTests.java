package hoainguyen.gama.GamaProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
