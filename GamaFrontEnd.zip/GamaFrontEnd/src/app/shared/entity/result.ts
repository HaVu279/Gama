export class Result {
    inputPath: string;
    outputPath: string;

    constructor(inputPath?: string, outputPath?: string) {
        this.inputPath = inputPath;
        this.outputPath = outputPath;
        
    }
}