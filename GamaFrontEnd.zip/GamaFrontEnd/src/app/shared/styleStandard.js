export default {
    maincolor: '#2d6028',
    margin: 15
}