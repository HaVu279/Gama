export class Constant {
    static readonly BACKEND_URL: string = 'http://localhost:8080';
}