import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menutesting',
  templateUrl: './menutesting.component.html',
  styleUrls: ['./menutesting.component.css']
})
export class MenutestingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
